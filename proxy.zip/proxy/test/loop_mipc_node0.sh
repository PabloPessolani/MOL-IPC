#!/bin/bash
if [ $# -ne 3 ]
then 
	echo "usage: $0  <nr_children> <loops> <nr_vms>"
	echo $#
	exit 1
fi
# --------------------------------- test multi VM sendrec --------------------
dmesg -c > /dev/null
for (( vm=0; vm < $3; vm++ ))
	do
	echo "loop$_r-s_server: nr_children=$1 loops=$2 nr_vms=$3" >  loop_msr_r-s-$vm.txt
done
#	
for i in {1..10}
	do
	for (( vm=0; vm < $3; vm++ ))
		do
		echo "[$i] loop_r-s_server $1 $2 $vm"
		/home/MoL_Module/mol-module/mol-ipc/proxy/test/loop_r-s_server $1 $2 $vm >> loop_msr_r-s-$vm.txt 2> loop_err.txt &
#		let pid$vm=$!
#		echo "pidvm=$pid$vm"
	done
	wait
	echo "all process exit"
#	for (( vm=0; vm < $3; vm++ ))
#		do
#		wait $pid$vm
#	done
	dmesg | grep ERROR
done
cat /proc/drvs/nodes >> loop_msr_r-s.txt
